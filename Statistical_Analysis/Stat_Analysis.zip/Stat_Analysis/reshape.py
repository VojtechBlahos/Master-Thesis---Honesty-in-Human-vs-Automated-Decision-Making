import pandas as pd
import numpy as np

WIDE = '/home/claude/data_v2.csv'
w = pd.read_csv(WIDE)

# ---- round-varying fields present in all 6 rounds ----
ROUND_FIELDS = ['dm_type', 'true_credit_score', 'reported_credit_score', 'did_apply',
                'is_approved', 'was_audited', 'round_tokens', 'app_choice',
                'audit_guess', 'true_audit_probability', 'id_in_group']

# ---- participant-level (round-invariant) ----
PART = ['participant.code', 'participant.role', 'participant.id_in_session',
        'participant.applicant_group', 'session.code', 'session.selected_round']

MES_ITEMS = ['mes_family', 'mes_coworker', 'mes_president', 'mes_official', 'mes_ai',
             'mes_refugee', 'mes_fraudster', 'mes_dolphin', 'mes_chicken', 'mes_appletree']

DEMO = ['age', 'gender', 'ai_use']

# person-level frame
person = w[PART].copy()
person.columns = ['pid', 'role', 'id_in_session', 'group', 'session', 'selected_round']

# demographics + MES live on round 1
for c in DEMO + MES_ITEMS:
    person[c] = w[f'HumanvsMachine.1.player.{c}']

# BART lives on round 6
person['bart_aapumps'] = w['HumanvsMachine.6.player.bart_aapumps']
person['bart_total_euros'] = w['HumanvsMachine.6.player.bart_total_euros']
person['final_payment_euros'] = w['HumanvsMachine.6.player.final_payment_euros']

# ---- build long frame ----
rows = []
for r in range(1, 7):
    blk = pd.DataFrame({'pid': w['participant.code'], 'round': r})
    for f in ROUND_FIELDS:
        blk[f] = w[f'HumanvsMachine.{r}.player.{f}']
    rows.append(blk)
long = pd.concat(rows, ignore_index=True)

long = long.merge(person, on='pid', how='left')
long = long.sort_values(['pid', 'round']).reset_index(drop=True)

# ================= DERIVED VARIABLES =================
long['ar'] = (long['dm_type'] == 'AR').astype(int)          # 1 = automated reviewer
long['order_hr_first'] = long['group'].isin(['A', 'C']).astype(int)
long['block'] = np.where(long['round'] <= 3, 1, 2)          # first vs second block
long['round_in_block'] = np.where(long['round'] <= 3, long['round'], long['round'] - 3)

t = pd.to_numeric(long['true_credit_score'], errors='coerce')
rep = pd.to_numeric(long['reported_credit_score'], errors='coerce')
app = pd.to_numeric(long['did_apply'], errors='coerce')

long['true_score'] = t
long['reported_score'] = rep
long['applied'] = app

long['eligible'] = (t <= 3).astype('float')                  # NaN-safe below
long.loc[t.isna(), 'eligible'] = np.nan

# lied: ineligible AND applied
long['lied'] = np.where((t > 3) & (app == 1), 1.0,
                 np.where((t > 3) & (app == 0), 0.0, np.nan))

# lie size only defined for liars
long['lie_size'] = np.where(long['lied'] == 1, t - rep, np.nan)

# max possible lie given the draw (must report 1..3 -> biggest lie = true - 1)
long['max_lie'] = np.where(t > 3, t - 1, np.nan)
long['lie_ratio'] = long['lie_size'] / long['max_lie']

long['belief'] = pd.to_numeric(long['audit_guess'], errors='coerce')
long['true_audit_p'] = pd.to_numeric(long['true_audit_probability'], errors='coerce')
long['belief_calib'] = long['belief'] / 100 - long['true_audit_p']

# MES derived (person level, broadcast)
for c in MES_ITEMS:
    long[c] = pd.to_numeric(long[c], errors='coerce')
# MES is only usable when ALL ten items are present. Session 1 contains partial
# submissions where only the first entity (family) committed; these are set to NaN.
_mes_n = long[MES_ITEMS].notna().sum(axis=1)
long.loc[(_mes_n > 0) & (_mes_n < len(MES_ITEMS)), MES_ITEMS] = np.nan
long['mes_n_items'] = long[MES_ITEMS].notna().sum(axis=1)
long['mes_total'] = long[MES_ITEMS].sum(axis=1, min_count=len(MES_ITEMS))
long['mes_gap'] = long['mes_official'] - long['mes_ai']     # human minus machine standing
long['has_mes'] = long['mes_ai'].notna().astype(int)

long['bart'] = pd.to_numeric(long['bart_aapumps'], errors='coerce')
long['age'] = pd.to_numeric(long['age'], errors='coerce')

# applicants only for the behavioural analyses
appl = long[long['role'] == 'Applicant'].copy()

long.to_csv('/home/claude/long_all.csv', index=False)
appl.to_csv('/home/claude/long_applicants.csv', index=False)

# ================= VALIDATION =================
print('=' * 62)
print('RESHAPE VALIDATION')
print('=' * 62)
print(f'wide rows           : {len(w)}')
print(f'long rows           : {len(long)}  (expect {len(w)*6})')
print(f'applicant rows      : {len(appl)}  (expect 94*6 = 564)')
print(f'unique applicants   : {appl.pid.nunique()}')
print()

print('--- dm_type by round (applicants) ---')
print(pd.crosstab(appl['round'], appl['dm_type']))
print()

print('--- order check: dm_type by group x block ---')
print(pd.crosstab([appl['group'], appl['block']], appl['dm_type']))
print()

print('--- app_choice values ---')
print(appl['app_choice'].value_counts(dropna=False))
print()

print('--- cross-check derived `lied` against app_choice ---')
chk = appl.copy()
chk['ac'] = chk['app_choice'].astype(str)
chk['ac_type'] = np.where(chk['ac'] == 'no_apply', 'no_apply',
                   np.where(chk['ac'] == 'eligible', 'eligible',
                   np.where(chk['ac'] == 'nan', 'missing', 'numeric(lie)')))
print(pd.crosstab(chk['ac_type'], chk['lied'], dropna=False))
print()

print('--- does numeric app_choice equal reported_score? ---')
num = chk[chk['ac_type'] == 'numeric(lie)'].copy()
num['acn'] = pd.to_numeric(num['ac'], errors='coerce')
print('   mismatches:', int((num['acn'] != num['reported_score']).sum()), 'of', len(num))
print()

print('--- eligible rows: is reported always == true? ---')
el = appl[appl['eligible'] == 1]
print('   eligible rows:', len(el), '| applied:', int(el['applied'].sum()))
print('   reported != true among eligible appliers:',
      int((el.loc[el['applied'] == 1, 'reported_score'] != el.loc[el['applied'] == 1, 'true_score']).sum()))
print()

print('--- reported_score range among liars ---')
lr = appl[appl['lied'] == 1]
print(lr['reported_score'].value_counts().sort_index())
print('   any reported > 3 among liars?', int((lr['reported_score'] > 3).sum()))
print()

print('--- missingness (applicants) ---')
for c in ['true_score', 'applied', 'belief', 'bart', 'mes_ai', 'age']:
    print(f'   {c:16s} missing {appl[c].isna().sum():4d} / {len(appl)}')
print()

print('--- partial MES submissions dropped ---')
_p = w[[f'HumanvsMachine.1.player.{c}' for c in MES_ITEMS]]
_n = _p.notna().sum(axis=1)
print(f'   complete (10/10): {(_n==10).sum()}   partial (1-9): {((_n>0)&(_n<10)).sum()}   none: {(_n==0).sum()}')
print(f'   partial cases carried only: {sorted(set(c.split(".")[-1] for c in _p.columns[_p[( _n>0)&(_n<10)].notna().any()]))}')
print()
print('--- MES availability by session (persons) ---')
p_appl = person[person['role'] == 'Applicant'].copy()
p_appl['mes_ai_n'] = pd.to_numeric(p_appl['mes_ai'], errors='coerce')
print(p_appl.groupby('session')['mes_ai_n'].agg(n='size', with_mes='count'))
