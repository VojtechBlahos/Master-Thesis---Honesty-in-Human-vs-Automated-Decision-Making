"""Estimation utilities: random-intercept GLMM (Gauss-Hermite), TOST, JZS Bayes factor."""
import numpy as np, pandas as pd
from scipy import optimize, stats, integrate
from scipy.special import expit, roots_hermitenorm
import warnings; warnings.filterwarnings('ignore')


# ----------------------------------------------------------------- GLMM
class RandomInterceptLogit:
    """Mixed-effects logistic regression with a participant random intercept.

    Marginal likelihood integrated by Gauss-Hermite quadrature:
        L_i = SUM_k w_k * PROD_t Bern(y_it | expit(x_it'b + sigma * z_k))
    with (z_k, w_k) the probabilists' Hermite nodes/weights (weights sum to 1).
    """

    def __init__(self, y, X, groups, names=None, n_nodes=40):
        self.y = np.asarray(y, float)
        self.X = np.asarray(X, float)
        self.g = pd.factorize(np.asarray(groups))[0]
        self.names = list(names) if names is not None else [f'x{i}' for i in range(self.X.shape[1])]
        self.k = self.X.shape[1]
        self.nodes, w = roots_hermitenorm(n_nodes)
        self.w = w / w.sum()
        self.n_groups = self.g.max() + 1
        self._idx = [np.where(self.g == j)[0] for j in range(self.n_groups)]

    def _negll(self, theta):
        b, sigma = theta[:self.k], np.exp(theta[self.k])
        eta0 = self.X @ b
        tot = 0.0
        for idx in self._idx:
            eta = eta0[idx][:, None] + sigma * self.nodes[None, :]
            p = expit(eta)
            yy = self.y[idx][:, None]
            # log P(y_it | node) summed over t, per node
            ll = np.sum(yy * np.log(p + 1e-300) + (1 - yy) * np.log(1 - p + 1e-300), axis=0)
            m = ll.max()
            tot += m + np.log(np.sum(self.w * np.exp(ll - m)) + 1e-300)
        return -tot

    def fit(self):
        start = np.zeros(self.k + 1)
        start[0] = np.log(max(self.y.mean(), 1e-3) / max(1 - self.y.mean(), 1e-3))
        res = optimize.minimize(self._negll, start, method='BFGS',
                                options={'maxiter': 2000, 'gtol': 1e-6})
        self.theta = res.x
        self.params = res.x[:self.k]
        self.sigma = float(np.exp(res.x[self.k]))
        self.loglike = -res.fun
        # numerical Hessian -> SEs
        H = _num_hessian(self._negll, res.x)
        try:
            cov = np.linalg.inv(H)
        except np.linalg.LinAlgError:
            cov = np.linalg.pinv(H)
        self.cov = cov
        self.bse = np.sqrt(np.clip(np.diag(cov)[:self.k], 0, None))
        self.z = self.params / self.bse
        self.pvalues = 2 * stats.norm.sf(np.abs(self.z))
        self.icc = self.sigma ** 2 / (self.sigma ** 2 + np.pi ** 2 / 3)
        self.n_obs = len(self.y)
        return self

    def table(self, exp=True):
        lo = self.params - 1.96 * self.bse
        hi = self.params + 1.96 * self.bse
        df = pd.DataFrame({'coef': self.params, 'SE': self.bse,
                           'z': self.z, 'p': self.pvalues,
                           'CI_lo': lo, 'CI_hi': hi}, index=self.names)
        if exp:
            df['OR'] = np.exp(df['coef'])
            df['OR_lo'] = np.exp(lo)
            df['OR_hi'] = np.exp(hi)
        return df


def _num_hessian(f, x, eps=1e-4):
    n = len(x)
    H = np.zeros((n, n))
    for i in range(n):
        for j in range(i, n):
            xpp, xpm, xmp, xmm = x.copy(), x.copy(), x.copy(), x.copy()
            xpp[i] += eps; xpp[j] += eps
            xpm[i] += eps; xpm[j] -= eps
            xmp[i] -= eps; xmp[j] += eps
            xmm[i] -= eps; xmm[j] -= eps
            H[i, j] = H[j, i] = (f(xpp) - f(xpm) - f(xmp) + f(xmm)) / (4 * eps ** 2)
    return H


def design(df, formula_vars, add_const=True):
    """Build a design matrix from a list of column names (already numeric)."""
    X = df[formula_vars].astype(float).to_numpy()
    names = list(formula_vars)
    if add_const:
        X = np.column_stack([np.ones(len(df)), X])
        names = ['Intercept'] + names
    return X, names


# --------------------------------------------------------------- TOST
def tost_paired(diff, bound, alpha=0.05):
    """Two one-sided tests for equivalence on paired differences.

    H0_lower: mu <= -bound   H0_upper: mu >= +bound
    Equivalence is concluded if BOTH are rejected.
    """
    d = np.asarray(diff, float)
    n = len(d)
    m, se = d.mean(), d.std(ddof=1) / np.sqrt(n)
    t_lo = (m + bound) / se           # test against -bound
    t_hi = (m - bound) / se           # test against +bound
    p_lo = stats.t.sf(t_lo, n - 1)    # one-sided, upper tail
    p_hi = stats.t.cdf(t_hi, n - 1)   # one-sided, lower tail
    p_tost = max(p_lo, p_hi)
    ci90 = stats.t.interval(1 - 2 * alpha, n - 1, loc=m, scale=se)
    return dict(mean=m, se=se, n=n, bound=bound,
                t_lower=t_lo, p_lower=p_lo, t_upper=t_hi, p_upper=p_hi,
                p_tost=p_tost, equivalent=p_tost < alpha,
                ci90_lo=ci90[0], ci90_hi=ci90[1])


# ------------------------------------------------- JZS Bayes factor
def bf10_ttest(t, n, r=0.707):
    """Default JZS Bayes factor for a one-sample / paired t-test (Rouder et al. 2009).
    Returns BF10; BF01 = 1 / BF10."""
    nu = n - 1

    def marg(g):
        return ((1 + n * g) ** -0.5
                * (1 + t ** 2 / ((1 + n * g) * nu)) ** (-(nu + 1) / 2)
                * (2 * np.pi) ** -0.5 * g ** -1.5
                * np.exp(-r ** 2 / (2 * g)) * r / np.sqrt(2 * np.pi) * np.sqrt(2 * np.pi))

    def prior_g(g):
        return (r ** 2 / (2 * np.pi)) ** 0.5 * g ** -1.5 * np.exp(-r ** 2 / (2 * g))

    num = integrate.quad(lambda g: (1 + n * g) ** -0.5
                         * (1 + t ** 2 / ((1 + n * g) * nu)) ** (-(nu + 1) / 2)
                         * prior_g(g), 0, np.inf, limit=200)[0]
    den = (1 + t ** 2 / nu) ** (-(nu + 1) / 2)
    return num / den


# --------------------------------------------- cluster bootstrap
def cluster_bootstrap(df, cluster_col, estimator, B=2000, seed=42):
    """Resample clusters with replacement; return array of estimates."""
    rng = np.random.default_rng(seed)
    clusters = df[cluster_col].unique()
    out = []
    for _ in range(B):
        pick = rng.choice(clusters, size=len(clusters), replace=True)
        parts = []
        for i, c in enumerate(pick):
            sub = df[df[cluster_col] == c].copy()
            sub['_bid'] = i
            parts.append(sub)
        bs = pd.concat(parts, ignore_index=True)
        try:
            out.append(estimator(bs))
        except Exception:
            out.append(np.nan)
    return np.array(out, dtype=float)
