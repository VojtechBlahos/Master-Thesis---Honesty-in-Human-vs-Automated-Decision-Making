from otree.api import *

doc = """
Exit page that redirects participants to a SoSciSurvey payment form
where they can enter their IBAN for bank transfer.
"""


class C(BaseConstants):
    NUM_ROUNDS = 1
    PLAYERS_PER_GROUP = None
    NAME_IN_URL = 'payout_referral'


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    pass


class Payout_Refer_Page(Page):
    @staticmethod
    def js_vars(player):
        # Pass participant label (seat number) as pid and total payoff as payoff.
        # Total payoff is not computed here; participants see it on the ThankYou screen.
        # Adjust the URL below once your SoSciSurvey project is live.
        return dict(
            p_pid=player.participant.label or player.participant.code,
        )


page_sequence = [Payout_Refer_Page]
