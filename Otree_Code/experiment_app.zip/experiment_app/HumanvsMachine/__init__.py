from otree.api import *
import numpy as np
import random

doc = """Honesty in Human vs. Automated Bureaucratic Decision-Making — WU Vienna MSc Thesis"""

BART_EXPLOSION_POINTS = [19, 7, 13, 16, 11, 8, 5, 3, 4, 14]


class C(BaseConstants):
    NAME_IN_URL = 'HumanvsMachine'
    PLAYERS_PER_GROUP = 13
    NUM_ROUNDS = 6
    NUM_APPLICANTS = 12
    NUM_REVIEWERS = 1
    BASE_TOKENS = 10
    APPLICANT_ROLE = 'Applicant'
    REVIEWER_ROLE = 'Reviewer'
    PART1_ROUNDS = 3
    PART2_ROUNDS = 3
    BOT_APPROVAL_RATE = 0.60

    ELIGIBLE_APPROVED         =  2
    ELIGIBLE_REJECTED         =  0
    LIE_APPROVED              =  2
    LIE_REJECTED              = -1
    HONEST_NO_APPLY           =  0

    REVIEWER_CORRECT_APPROVAL =  2
    REVIEWER_WRONG_REJECTION  = -2
    REVIEWER_CAUGHT_LIAR      =  3
    REVIEWER_APPROVED_LIAR    = -3


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    # Consent (blank=True so oTree accepts unchecked; error_message enforces True)
    consent = models.BooleanField(
        blank=True,
        label='I confirm I am 18 or older and I consent to participate in this study.')

    # Role and subgroup (copied from participant each round)
    applicant_group = models.StringField(blank=True, initial='')
    dm_type         = models.StringField(blank=True, initial='')

    # Credit score and application
    true_credit_score     = models.IntegerField(min=1, max=10, blank=True)
    reported_credit_score = models.IntegerField(min=0, max=10, blank=True, initial=0)
    did_apply             = models.BooleanField(initial=False)
    is_approved           = models.BooleanField(blank=True)
    was_audited           = models.BooleanField(initial=False)
    round_tokens          = models.IntegerField(initial=10)
    app_choice                = models.StringField(blank=True, initial='')
    reviewer_decisions_json   = models.LongStringField(blank=True, initial='')
    bart_results_json         = models.LongStringField(blank=True, initial='')

    # Audit guess (integer 0–100, applicants only)
    audit_guess            = models.IntegerField(min=0, max=100, blank=True,
        label="What is the probability (0–100%) of a submitted application "
              "to be audited this round? Enter an integer number.")
    true_audit_probability = models.FloatField(initial=0.0)
    won_guessing_bonus     = models.BooleanField(initial=False)
    final_payment_euros    = models.FloatField(initial=0.0)

    # Demographics (round 1, before role revealed)
    age    = models.IntegerField(min=18, max=100, blank=True, label='Age')
    gender = models.StringField(blank=True,
        choices=['Male', 'Female', 'Non-binary', 'Prefer not to say'],
        label='Gender',
        widget=widgets.RadioSelect)
    ai_use = models.StringField(blank=True,
        choices=['Never', 'Monthly', 'Weekly', 'Daily',
                 'Several times a day', 'Prefer not to say'],
        label='How often do you use Generative AI tools?',
        widget=widgets.RadioSelect)

    # MES — 10 entities, 4-point scale 0–3 (Crimston et al. 2016)
    mes_family    = models.IntegerField(blank=True, choices=[0,1,2,3],
        label='A Close Family Member',
        widget=widgets.RadioSelectHorizontal)
    mes_coworker  = models.IntegerField(blank=True, choices=[0,1,2,3],
        label='A Co-Worker',
        widget=widgets.RadioSelectHorizontal)
    mes_president = models.IntegerField(blank=True, choices=[0,1,2,3],
        label='A Country President',
        widget=widgets.RadioSelectHorizontal)
    mes_official  = models.IntegerField(blank=True, choices=[0,1,2,3],
        label='A Public Official',
        widget=widgets.RadioSelectHorizontal)
    mes_ai        = models.IntegerField(blank=True, choices=[0,1,2,3],
        label='A Digital System (e.g. AI, automatic algorithm)',
        widget=widgets.RadioSelectHorizontal)
    mes_refugee   = models.IntegerField(blank=True, choices=[0,1,2,3],
        label='A Refugee',
        widget=widgets.RadioSelectHorizontal)
    mes_fraudster = models.IntegerField(blank=True, choices=[0,1,2,3],
        label='A Fraudster',
        widget=widgets.RadioSelectHorizontal)
    mes_dolphin   = models.IntegerField(blank=True, choices=[0,1,2,3],
        label='A Dolphin',
        widget=widgets.RadioSelectHorizontal)
    mes_chicken   = models.IntegerField(blank=True, choices=[0,1,2,3],
        label='A Chicken',
        widget=widgets.RadioSelectHorizontal)
    mes_appletree = models.IntegerField(blank=True, choices=[0,1,2,3],
        label='An Apple Tree',
        widget=widgets.RadioSelectHorizontal)

    # Comprehension checks (round 1)
    comp_q1 = models.StringField(
        choices=['Only Applicant', 'Only Reviewer', 'Both Applicant and Reviewer'],
        label='Before any audits, who can see the true credit score of an applicant?',
        widget=widgets.RadioSelect)
    comp_q2 = models.StringField(
        choices=['1 or lower', '3 or lower', '5 or lower'],
        label='What credit score makes an applicant eligible for financial aid?',
        widget=widgets.RadioSelect)
    comp_q3 = models.StringField(
        choices=['The 3 rounds of Part 1', 'The 3 rounds of Part 2',
                 'One randomly chosen round out of all 6'],
        label='Which round will determine your final payment?',
        widget=widgets.RadioSelect)

    # BART fields (round 6, applicants only)
    bart_pumps_b1     = models.IntegerField(initial=0)
    bart_pumps_b2     = models.IntegerField(initial=0)
    bart_pumps_b3     = models.IntegerField(initial=0)
    bart_pumps_b4     = models.IntegerField(initial=0)
    bart_pumps_b5     = models.IntegerField(initial=0)
    bart_pumps_b6     = models.IntegerField(initial=0)
    bart_pumps_b7     = models.IntegerField(initial=0)
    bart_pumps_b8     = models.IntegerField(initial=0)
    bart_pumps_b9     = models.IntegerField(initial=0)
    bart_pumps_b10    = models.IntegerField(initial=0)
    bart_exploded_b1  = models.BooleanField(initial=False)
    bart_exploded_b2  = models.BooleanField(initial=False)
    bart_exploded_b3  = models.BooleanField(initial=False)
    bart_exploded_b4  = models.BooleanField(initial=False)
    bart_exploded_b5  = models.BooleanField(initial=False)
    bart_exploded_b6  = models.BooleanField(initial=False)
    bart_exploded_b7  = models.BooleanField(initial=False)
    bart_exploded_b8  = models.BooleanField(initial=False)
    bart_exploded_b9  = models.BooleanField(initial=False)
    bart_exploded_b10 = models.BooleanField(initial=False)
    bart_total_euros  = models.FloatField(initial=0.0)
    bart_aapumps      = models.FloatField(initial=0.0)


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def draw_credit_score():
    score = np.random.normal(5.5, 1.8)
    score = int(round(score))
    return max(1, min(10, score))


def get_condition(player):
    """Return 'HR' or 'AR' for the player this round."""
    if player.participant.role == C.REVIEWER_ROLE:
        return 'HR'
    grp = player.participant.applicant_group
    r   = player.round_number
    if grp in ('A', 'C'):
        return 'HR' if r <= C.PART1_ROUNDS else 'AR'
    else:
        return 'AR' if r <= C.PART1_ROUNDS else 'HR'


def creating_session(subsession):
    if subsession.round_number == 1:
        for group in subsession.get_groups():
            players = group.get_players()
            for i, player in enumerate(players):
                participant = player.participant
                if i == 0:
                    participant.role           = C.REVIEWER_ROLE
                    participant.applicant_group = None
                else:
                    participant.role = C.APPLICANT_ROLE
                    gn = group.id_in_subsession  # 1 or 2
                    if gn == 1:
                        participant.applicant_group = 'A' if i % 2 == 1 else 'B'
                    else:
                        participant.applicant_group = 'C' if i % 2 == 1 else 'D'

    # Set per-round player fields for every round
    for group in subsession.get_groups():
        for player in group.get_players():
            player.dm_type         = get_condition(player)
            player.applicant_group = player.participant.applicant_group or ''
            if player.participant.role == C.APPLICANT_ROLE:
                player.true_credit_score = draw_credit_score()


# ---------------------------------------------------------------------------
# Payoff functions
# ---------------------------------------------------------------------------

def process_ar_decisions(group):
    """Run bot audit logic for AR-condition applicants who applied."""
    ar_applicants = [
        p for p in group.get_players()
        if p.participant.role == C.APPLICANT_ROLE
        and p.dm_type == 'AR'
        and p.did_apply
    ]
    if not ar_applicants:
        return

    audited = random.choice(ar_applicants)
    audited.was_audited = True
    audited.is_approved = (audited.true_credit_score <= 3)

    for p in ar_applicants:
        if p != audited:
            p.is_approved = (random.random() < C.BOT_APPROVAL_RATE)


def calculate_applicant_tokens(player):
    if not player.did_apply:
        player.round_tokens = C.BASE_TOKENS + C.HONEST_NO_APPLY
    else:
        approved = player.field_maybe_none('is_approved') or False
        if player.true_credit_score <= 3:
            player.round_tokens = C.BASE_TOKENS + (
                C.ELIGIBLE_APPROVED if approved else C.ELIGIBLE_REJECTED)
        else:
            player.round_tokens = C.BASE_TOKENS + (
                C.LIE_APPROVED if approved else C.LIE_REJECTED)


def calculate_reviewer_tokens(reviewer, group):
    hr_applicants = [
        p for p in group.get_players()
        if p.participant.role == C.APPLICANT_ROLE
        and p.dm_type == 'HR'
        and p.did_apply
    ]
    if not hr_applicants:
        reviewer.round_tokens = C.BASE_TOKENS
        return

    selected = random.choice(hr_applicants)
    true_cs  = selected.true_credit_score
    approved = selected.is_approved

    if true_cs <= 3:
        change = C.REVIEWER_CORRECT_APPROVAL if approved else C.REVIEWER_WRONG_REJECTION
    else:
        change = C.REVIEWER_APPROVED_LIAR if approved else C.REVIEWER_CAUGHT_LIAR

    reviewer.round_tokens = C.BASE_TOKENS + change


def set_payoffs(group):
    players   = group.get_players()
    reviewer  = next(p for p in players if p.participant.role == C.REVIEWER_ROLE)
    applicants = [p for p in players if p.participant.role == C.APPLICANT_ROLE]

    # Bot decisions for AR applicants
    process_ar_decisions(group)

    # True audit probability per subgroup (1 / applications submitted that round)
    for sg in ['A', 'B', 'C', 'D']:
        sg_applied = [p for p in applicants
                      if p.participant.applicant_group == sg and p.did_apply]
        n    = len(sg_applied)
        prob = (1.0 / n) if n > 0 else 0.0
        for p in applicants:
            if p.participant.applicant_group == sg:
                p.true_audit_probability = prob

    for p in applicants:
        calculate_applicant_tokens(p)
    calculate_reviewer_tokens(reviewer, group)


# ---------------------------------------------------------------------------
# PAGES
# ---------------------------------------------------------------------------

class Consent(Page):
    form_model  = 'player'
    form_fields = ['consent']

    @staticmethod
    def is_displayed(player):
        return player.round_number == 1

    @staticmethod
    def error_message(player, values):
        if not values.get('consent'):
            return 'You must confirm your consent to continue.'


class Welcome(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == 1


class DemographicsAndMES(Page):
    form_model  = 'player'
    form_fields = [
        'age', 'gender', 'ai_use',
        'mes_family', 'mes_coworker', 'mes_president', 'mes_official',
        'mes_ai', 'mes_refugee', 'mes_fraudster',
        'mes_dolphin', 'mes_chicken', 'mes_appletree',
    ]

    @staticmethod
    def is_displayed(player):
        return player.round_number == 1


class ExperimentDetails1(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == 1

    @staticmethod
    def vars_for_template(player):
        return dict(scores=list(range(1, 11)))


class ExperimentDetails2(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == 1


class ApplicantRoleIntro(Page):
    @staticmethod
    def is_displayed(player):
        return (player.round_number == 1 and
                player.participant.role == C.APPLICANT_ROLE)


class ReviewerRoleIntro(Page):
    @staticmethod
    def is_displayed(player):
        return (player.round_number == 1 and
                player.participant.role == C.REVIEWER_ROLE)


class ComprehensionCheck1(Page):
    form_model  = 'player'
    form_fields = ['comp_q1']

    @staticmethod
    def is_displayed(player):
        return player.round_number == 1

    @staticmethod
    def error_message(player, values):
        if values['comp_q1'] != 'Only Applicant':
            return ('Incorrect. The true credit score is private information — '
                    'only the applicant knows it. The reviewer only sees the score '
                    'the applicant chooses to report. An audit reveals the true score '
                    'to either the Human Reviewer or Automated Algorithm, but they see '
                    'only the true score of the one audited application per round.')


class ComprehensionCheck2(Page):
    form_model  = 'player'
    form_fields = ['comp_q2']

    @staticmethod
    def is_displayed(player):
        return player.round_number == 1

    @staticmethod
    def error_message(player, values):
        if values['comp_q2'] != '3 or lower':
            return ('Incorrect. Only credit scores of 1, 2, or 3 make an applicant eligible '
                    'for financial aid. Scores of 4–10 are not eligible.')


class ComprehensionCheck3(Page):
    form_model  = 'player'
    form_fields = ['comp_q3']

    @staticmethod
    def is_displayed(player):
        return player.round_number == 1

    @staticmethod
    def error_message(player, values):
        if values['comp_q3'] != 'One randomly chosen round out of all 6':
            return ('Incorrect. At the end of the experiment, one round is randomly selected '
                    'from all 6 rounds. Your payment is based on your token earnings in that '
                    'randomly chosen round.')


class GroupFormationWait(WaitPage):
    wait_for_all_groups = True
    title_text = 'Please wait'
    body_text  = 'Waiting for all participants to finish the instructions.'

    @staticmethod
    def is_displayed(player):
        return player.round_number == 1


class CreditScoreAndAuditGuess(Page):
    form_model  = 'player'
    form_fields = ['audit_guess']

    @staticmethod
    def is_displayed(player):
        return player.participant.role == C.APPLICANT_ROLE

    @staticmethod
    def vars_for_template(player):
        return dict(
            true_credit_score=player.true_credit_score,
            is_eligible=(player.true_credit_score <= 3),
            dm_type=player.dm_type,
            round_number=player.round_number,
            scores=list(range(1, 11)),
        )


class ApplicationDecision(Page):
    form_model  = 'player'
    form_fields = ['app_choice']

    @staticmethod
    def is_displayed(player):
        return player.participant.role == C.APPLICANT_ROLE

    @staticmethod
    def vars_for_template(player):
        eligible = player.true_credit_score <= 3
        return dict(
            true_credit_score=player.true_credit_score,
            is_eligible=eligible,
            dm_type=player.dm_type,
            round_number=player.round_number,
            scores=list(range(1, 11)),
        )

    @staticmethod
    def error_message(player, values):
        if player.true_credit_score > 3 and not values.get('app_choice'):
            return 'Please select an option before continuing.'

    @staticmethod
    def before_next_page(player, timeout_happened):
        choice = player.app_choice
        if player.true_credit_score <= 3:
            player.did_apply             = True
            player.reported_credit_score = player.true_credit_score
        elif choice == 'no_apply':
            player.did_apply             = False
            player.reported_credit_score = 0
        elif choice in ('1', '2', '3'):
            player.did_apply             = True
            player.reported_credit_score = int(choice)


class WaitForApplicants(WaitPage):
    title_text = 'Please wait'
    body_text  = 'Waiting for all applicants to submit their applications.'

    @staticmethod
    def is_displayed(player):
        return player.participant.role == C.REVIEWER_ROLE


class ReviewerDecision(Page):
    form_model  = 'player'
    form_fields = ['reviewer_decisions_json']

    @staticmethod
    def is_displayed(player):
        return player.participant.role == C.REVIEWER_ROLE

    @staticmethod
    def vars_for_template(player):
        hr_applicants = [
            p for p in player.group.get_players()
            if p.participant.role == C.APPLICANT_ROLE
            and p.dm_type == 'HR'
            and p.did_apply
        ]
        applicant_data = [
            dict(id_in_group=p.id_in_group,
                 reported_credit_score=p.reported_credit_score,
                 true_credit_score=p.true_credit_score,
                 app_num=idx + 1)
            for idx, p in enumerate(hr_applicants)
        ]
        return dict(
            applicants=applicant_data,
            num_applicants=len(applicant_data),
            round_number=player.round_number,
        )

    @staticmethod
    def before_next_page(player, timeout_happened):
        import json
        if not player.reviewer_decisions_json:
            return
        try:
            payload = json.loads(player.reviewer_decisions_json)
        except (ValueError, TypeError):
            return
        audited_id = payload.get('audited_id')
        decisions  = payload.get('decisions', {})
        group_players = {
            p.id_in_group: p
            for p in player.group.get_players()
            if p.participant.role == C.APPLICANT_ROLE
        }
        for id_str, decision in decisions.items():
            ap = group_players.get(int(id_str))
            if ap is not None:
                ap.is_approved  = (decision == 'approve')
                ap.was_audited  = (audited_id == int(id_str))


class DecisionWait(WaitPage):
    after_all_players_arrive = set_payoffs
    title_text = 'Please wait'
    body_text  = 'Waiting for all decisions to be finalised.'


class RoundResults(Page):
    @staticmethod
    def vars_for_template(player):
        is_applicant = (player.participant.role == C.APPLICANT_ROLE)
        token_change = player.round_tokens - C.BASE_TOKENS
        d = dict(
            is_applicant=is_applicant,
            round_number=player.round_number,
            round_tokens=player.round_tokens,
            token_change=token_change,
            dm_type=player.dm_type,
        )
        if is_applicant:
            d.update(dict(
                did_apply=player.did_apply,
                true_credit_score=player.true_credit_score,
                is_eligible=(player.true_credit_score <= 3),
                reported_credit_score=player.reported_credit_score,
                is_approved=player.field_maybe_none('is_approved'),
                was_audited=player.was_audited,
            ))
        return d


class PartIntro(Page):
    """Shown at the start of Part 1 (round 1) and Part 2 (round 4) to all players."""
    @staticmethod
    def is_displayed(player):
        return player.round_number in (1, 4)

    @staticmethod
    def vars_for_template(player):
        is_reviewer = (player.participant.role == C.REVIEWER_ROLE)
        part_num    = 1 if player.round_number == 1 else 2
        rounds_str  = '1–3' if part_num == 1 else '4–6'
        return dict(
            is_reviewer=is_reviewer,
            part_num=part_num,
            rounds_str=rounds_str,
            dm_type=player.dm_type,
        )


class BARTIntro(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == 6


class BARTPage(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == 6

    @staticmethod
    def vars_for_template(player):
        return dict(
            num_balloons=10,
            explosion_points=BART_EXPLOSION_POINTS,
        )

    form_model  = 'player'
    form_fields = ['bart_results_json']

    @staticmethod
    def before_next_page(player, timeout_happened):
        import json
        if not player.bart_results_json:
            return
        try:
            data = json.loads(player.bart_results_json)
        except (ValueError, TypeError):
            return
        pumps_list    = data.get('pumps', [0]*10)
        exploded_list = data.get('exploded', [False]*10)
        total         = data.get('total', 0.0)
        for i in range(10):
            setattr(player, f'bart_pumps_b{i+1}',    pumps_list[i]    if i < len(pumps_list)    else 0)
            setattr(player, f'bart_exploded_b{i+1}', exploded_list[i] if i < len(exploded_list) else False)
        player.bart_total_euros = round(float(total), 2)
        non_exploded = [pumps_list[i] for i in range(10) if not exploded_list[i]]
        player.bart_aapumps = (sum(non_exploded) / len(non_exploded)) if non_exploded else 0.0


class ThankYou(Page):
    @staticmethod
    def is_displayed(player):
        return player.round_number == 6

    @staticmethod
    def vars_for_template(player):
        session = player.session

        # Select payment round once per session
        if 'selected_round' not in session.vars:
            session.vars['selected_round'] = random.randint(1, C.NUM_ROUNDS)

        # Compute guessing bonus winners once per session
        if 'bonus_winners' not in session.vars:
            sel = session.vars['selected_round']
            try:
                sub_r        = player.subsession.in_round(sel)
                all_players  = sub_r.get_players()
            except Exception:
                all_players = []

            bonus_winners = {}
            for sg in ['A', 'B', 'C', 'D']:
                sg_players = [
                    p for p in all_players
                    if p.participant.role == C.APPLICANT_ROLE
                    and p.participant.applicant_group == sg
                    and p.field_maybe_none('audit_guess') is not None
                ]
                if sg_players:
                    true_pct     = sg_players[0].true_audit_probability * 100
                    closest_err  = min(abs(p.audit_guess - true_pct) for p in sg_players)
                    candidates   = [p for p in sg_players
                                    if abs(p.audit_guess - true_pct) == closest_err]
                    winner       = random.choice(candidates)
                    bonus_winners[sg] = winner.participant.code
                    winner.won_guessing_bonus = True

            session.vars['bonus_winners'] = bonus_winners

        selected_round = session.vars['selected_round']
        player_r       = player.in_round(selected_round)
        tokens         = player_r.round_tokens
        is_applicant   = (player.participant.role == C.APPLICANT_ROLE)
        p_label        = player.participant.label or player.participant.code

        if is_applicant:
            sg          = player.participant.applicant_group
            won_bonus   = (session.vars['bonus_winners'].get(sg) ==
                           player.participant.code)
            bonus_euros = 2 if won_bonus else 0
            bart_euros  = player.bart_total_euros
            total       = tokens + bart_euros + bonus_euros
            return dict(
                is_applicant=True,
                selected_round=selected_round,
                tokens=tokens,
                euros_from_tokens=tokens,
                bart_earnings_fmt='%.2f' % bart_euros,
                won_bonus=won_bonus,
                bonus_euros=bonus_euros,
                total_euros_fmt='%.2f' % total,
                participant_label=p_label,
            )
        else:
            bart_euros = player.bart_total_euros
            total      = tokens + bart_euros
            return dict(
                is_applicant=False,
                selected_round=selected_round,
                tokens=tokens,
                euros_from_tokens=tokens,
                bart_earnings_fmt='%.2f' % bart_euros,
                total_euros_fmt='%.2f' % total,
                participant_label=p_label,
            )

    @staticmethod
    def before_next_page(player, timeout_happened):
        session      = player.session
        selected_round = session.vars['selected_round']
        player_r     = player.in_round(selected_round)
        tokens       = player_r.round_tokens
        bart_euros   = player.bart_total_euros
        if player.participant.role == C.APPLICANT_ROLE:
            sg          = player.participant.applicant_group
            won_bonus   = (session.vars.get('bonus_winners', {}).get(sg) ==
                           player.participant.code)
            bonus_euros = 2 if won_bonus else 0
            player.final_payment_euros = round(tokens + bart_euros + bonus_euros, 2)
        else:
            player.final_payment_euros = round(tokens + bart_euros, 2)


page_sequence = [
    Welcome,
    DemographicsAndMES,
    ExperimentDetails1,
    ExperimentDetails2,
    ApplicantRoleIntro,
    ReviewerRoleIntro,
    ComprehensionCheck1,
    ComprehensionCheck2,
    ComprehensionCheck3,
    GroupFormationWait,
    PartIntro,
    CreditScoreAndAuditGuess,
    ApplicationDecision,
    WaitForApplicants,
    ReviewerDecision,
    DecisionWait,
    RoundResults,
    BARTIntro,
    BARTPage,
    ThankYou,
]
